import { describe, it, expect, beforeEach, vi } from 'vitest';
import { appRouter } from '../routers';
import { TRPCError } from '@trpc/server';
import type { TrpcContext } from '../_core/context';

type AuthenticatedUser = NonNullable<TrpcContext['user']>;

function createTestContext(ip: string = '127.0.0.1'): TrpcContext {
  return {
    user: null,
    req: {
      protocol: 'https',
      headers: {
        'x-forwarded-for': ip,
      },
    } as TrpcContext['req'],
    res: {
      clearCookie: () => {},
    } as TrpcContext['res'],
  };
}

describe('contact.submit', () => {
  beforeEach(() => {
    // Clear rate limit map between tests
    vi.clearAllMocks();
  });

  it('should successfully submit a valid contact form with email', async () => {
    const ctx = createTestContext('192.168.1.1');
    const caller = appRouter.createCaller(ctx);

    const result = await caller.contact.submit({
      name: 'John Doe',
      email: 'john@example.com',
      message: 'I would like to learn more about your services.',
    });

    expect(result.success).toBe(true);
    expect(result.message).toContain('Thank you');
  });

  it('should successfully submit a valid contact form with WhatsApp', async () => {
    const ctx = createTestContext('192.168.1.1');
    const caller = appRouter.createCaller(ctx);

    const result = await caller.contact.submit({
      name: 'John Doe',
      email: '+212612345678',
      message: 'I would like to learn more about your services.',
    });

    expect(result.success).toBe(true);
    expect(result.message).toContain('Thank you');
  });

  it('should reject invalid email', async () => {
    const ctx = createTestContext('192.168.1.2');
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.contact.submit({
        name: 'John Doe',
        email: 'invalid-email',
        message: 'I would like to learn more about your services.',
      });
      expect.fail('Should have thrown an error');
    } catch (error) {
      expect(error).toBeInstanceOf(TRPCError);
    }
  });

  it('should reject invalid WhatsApp format', async () => {
    const ctx = createTestContext('192.168.1.2');
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.contact.submit({
        name: 'John Doe',
        email: '+212123',
        message: 'I would like to learn more about your services.',
      });
      expect.fail('Should have thrown an error');
    } catch (error) {
      expect(error).toBeInstanceOf(TRPCError);
    }
  });

  it('should reject short name', async () => {
    const ctx = createTestContext('192.168.1.3');
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.contact.submit({
        name: 'J',
        email: 'john@example.com',
        message: 'I would like to learn more about your services.',
      });
      expect.fail('Should have thrown an error');
    } catch (error) {
      expect(error).toBeInstanceOf(TRPCError);
    }
  });

  it('should reject short message', async () => {
    const ctx = createTestContext('192.168.1.4');
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.contact.submit({
        name: 'John Doe',
        email: 'john@example.com',
        message: 'Short',
      });
      expect.fail('Should have thrown an error');
    } catch (error) {
      expect(error).toBeInstanceOf(TRPCError);
    }
  });

  it('should enforce rate limiting (max 5 requests per IP per hour)', async () => {
    const ip = '192.168.1.5';
    const validData = {
      name: 'John Doe',
      email: 'john@example.com',
      message: 'I would like to learn more about your services.',
    };

    // First 5 requests should succeed
    for (let i = 0; i < 5; i++) {
      const ctx = createTestContext(ip);
      const caller = appRouter.createCaller(ctx);
      const result = await caller.contact.submit(validData);
      expect(result.success).toBe(true);
    }

    // 6th request should be rate limited
    const ctx = createTestContext(ip);
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.contact.submit(validData);
      expect.fail('Should have thrown a rate limit error');
    } catch (error) {
      expect(error).toBeInstanceOf(TRPCError);
      const trpcError = error as TRPCError<any>;
      expect(trpcError.code).toBe('TOO_MANY_REQUESTS');
    }
  });

  it('should allow different IPs to submit independently', async () => {
    const validData = {
      name: 'John Doe',
      email: 'john@example.com',
      message: 'I would like to learn more about your services.',
    };

    // Different IPs should not share rate limit
    for (let i = 0; i < 3; i++) {
      const ctx = createTestContext(`192.168.1.${100 + i}`);
      const caller = appRouter.createCaller(ctx);
      const result = await caller.contact.submit(validData);
      expect(result.success).toBe(true);
    }
  });
});
