import { z } from 'zod';
import { publicProcedure, router } from '../_core/trpc';
import { TRPCError } from '@trpc/server';
import { notifyOwner } from '../_core/notification';
import { ENV } from '../_core/env';

// Rate limiting: store IP -> request count and timestamp
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();

const RATE_LIMIT_WINDOW = 60 * 60 * 1000; // 1 hour in milliseconds
const RATE_LIMIT_MAX_REQUESTS = 5;

function getClientIp(req: any): string {
  // Try to get the real IP from various headers
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) {
    return typeof forwarded === 'string' ? forwarded.split(',')[0].trim() : forwarded[0];
  }
  return req.headers['x-real-ip'] || req.socket?.remoteAddress || 'unknown';
}

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const record = rateLimitMap.get(ip);

  if (!record || now > record.resetTime) {
    // New window or expired
    rateLimitMap.set(ip, { count: 1, resetTime: now + RATE_LIMIT_WINDOW });
    return true;
  }

  if (record.count < RATE_LIMIT_MAX_REQUESTS) {
    record.count++;
    return true;
  }

  return false;
}

const contactFormSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  email: z.string()
    .min(1, 'Email or WhatsApp is required')
    .refine(
      (value) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const phoneRegex = /^\+?\d{7,15}$/;
        return emailRegex.test(value) || phoneRegex.test(value);
      },
      'Please provide a valid email or phone number'
    ),
  message: z.string().min(10, 'Message must be at least 10 characters').max(5000),
});

type ContactFormInput = z.infer<typeof contactFormSchema>;

async function sendEmail(data: ContactFormInput): Promise<void> {
  // TODO: Implement email sending via Nodemailer
  // For now, this is a placeholder that logs the data
  console.log('Email would be sent:', {
    to: ENV.contactEmail,
    subject: `New Contact Form Submission from ${data.name}`,
    text: `Name: ${data.name}\nEmail: ${data.email}\n\nMessage:\n${data.message}`,
  });
}

async function triggerN8nWebhook(data: ContactFormInput): Promise<void> {
  if (!ENV.n8nWebhookUrl) {
    console.log('N8N webhook URL not configured, skipping webhook trigger');
    return;
  }

  try {
    const response = await fetch(ENV.n8nWebhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: data.name,
        email: data.email,
        message: data.message,
        timestamp: new Date().toISOString(),
      }),
    });

    if (!response.ok) {
      console.error('N8N webhook failed:', response.status, response.statusText);
    }
  } catch (error) {
    console.error('Error triggering N8N webhook:', error);
  }
}

export const contactRouter = router({
  submit: publicProcedure
    .input(contactFormSchema)
    .mutation(async ({ input, ctx }) => {
      // Get client IP for rate limiting
      const clientIp = getClientIp(ctx.req);

      // Check rate limit
      if (!checkRateLimit(clientIp)) {
        throw new TRPCError({
          code: 'TOO_MANY_REQUESTS',
          message: 'Too many requests. Please try again later.',
        });
      }

      try {
        // Send email notification
        await sendEmail(input);

        // Trigger N8N webhook
        await triggerN8nWebhook(input);

        // Notify owner
        await notifyOwner({
          title: 'New Contact Form Submission',
          content: `From: ${input.name} (${input.email})\n\nMessage:\n${input.message}`,
        });

        return {
          success: true,
          message: 'Thank you for your message! We will get back to you soon.',
        };
      } catch (error) {
        console.error('Error processing contact form:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to process your request. Please try again later.',
        });
      }
    }),
});
