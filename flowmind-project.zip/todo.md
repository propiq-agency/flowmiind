# FlowMind Website - Development TODO

## Phase 1: Setup & Styling
- [x] Configure global styles with Sora and DM Sans fonts
- [x] Set up Tailwind CSS with custom color palette (#1a6b4a green, #e8f5ef light green)
- [x] Create reusable component structure

## Phase 2: UI Components & Sections
- [x] Navbar with sticky positioning, blur effect on scroll, logo split (Flow/Mind), nav links, CTA button
- [x] Hero section with tag, headline, subtext, two CTA buttons, stats row
- [x] What We Do section with 2×2 service card grid (AI Support, WhatsApp, N8N, Data Analysis)
- [x] How It Works section with 3 numbered steps
- [x] Our Work section with 2×2 project card grid with result badges
- [x] Pricing section with 3 cards (Basic/Advanced/Custom) with Advanced highlighted
- [x] Contact section with two-column layout (info + form)
- [x] Footer with logo and copyright text

## Phase 3: Backend & Form Handling
- [x] Create tRPC contact form procedure with Zod validation
- [x] Implement rate limiting (max 5 requests per IP per hour)
- [x] Set up n8n webhook integration
- [x] Add owner notification on form submission
- [x] Add environment variables for SMTP, n8n webhook, phone, email
- [x] Write and pass vitest tests for contact form API
- [x] Connect frontend form to backend API with loading states

## Phase 4: Polish & Testing
- [x] Test all sections for responsiveness
- [x] Verify smooth scroll navigation
- [x] Test contact form validation and rate limiting
- [x] Polish hover effects and animations
- [x] Verify all links and CTAs work correctly

## Phase 5: Deployment
- [x] Create checkpoint
- [x] Deploy to production
- [x] Verify live website functionality

## Updates - Global Expansion

### Pricing Changes
- [x] Update pricing to USD: Chatbot/WhatsApp $169, Emails Workflow $199, Data Analysis Agent $349
- [x] Change pricing structure from 3 tiers to service-based pricing
- [x] Update "Custom" tier to "Any other workflow / agent - Contact us"

### Contact Information
- [x] Update phone number to 0780852358
- [x] Update email to aadammm877@gmail.com
- [x] Update "Let's Talk" section heading

### Remove Morocco References
- [x] Remove "Morocco" from hero section tag
- [x] Remove "Moroccan startups and real estate companies" from hero subtext
- [x] Remove "Built in Morocco 🇲🇦" from footer
- [x] Update all copy to be globally applicable
