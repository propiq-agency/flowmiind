import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Mail, MessageSquare, Zap, BarChart3, CheckCircle2, ArrowRight, Menu, X, Loader2 } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const submitMutation = trpc.contact.submit.useMutation();
  const isLoading = submitMutation.isPending;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await submitMutation.mutateAsync(formData);
      toast.success('Thank you! We will get back to you soon.');
      setFormData({ name: '', email: '', message: '' });
    } catch (error: any) {
      const message = error?.message || 'Failed to send message. Please try again.';
      toast.error(message);
    }
  };

  return (
    <div className="card-base">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">Name</label>
          <Input
            type="text"
            name="name"
            placeholder="Your name"
            className="w-full"
            value={formData.name}
            onChange={handleChange}
            required
            disabled={isLoading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Email or Phone</label>
          <Input
            type="text"
            name="email"
            placeholder="your@email.com or +1234567890"
            className="w-full"
            value={formData.email}
            onChange={handleChange}
            required
            disabled={isLoading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Message</label>
          <Textarea
            name="message"
            placeholder="Tell us about your project..."
            className="w-full min-h-32"
            value={formData.message}
            onChange={handleChange}
            required
            disabled={isLoading}
          />
        </div>

        <button
          type="submit"
          className="btn-primary w-full flex items-center justify-center gap-2"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 size={18} className="animate-spin" />
              Sending...
            </>
          ) : (
            'Send Message'
          )}
        </button>
      </form>
    </div>
  );
}

export default function Home() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navbar */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? 'bg-background/80 backdrop-blur-md border-b border-border' : 'bg-transparent'
        }`}
      >
        <div className="container flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-1 font-bold text-xl">
            <span className="text-foreground">Flow</span>
            <span className="text-accent">Mind</span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <button
              onClick={() => scrollToSection('services')}
              className="text-sm font-medium hover:text-accent transition-colors"
            >
              Services
            </button>
            <button
              onClick={() => scrollToSection('work')}
              className="text-sm font-medium hover:text-accent transition-colors"
            >
              Work
            </button>
            <button
              onClick={() => scrollToSection('pricing')}
              className="text-sm font-medium hover:text-accent transition-colors"
            >
              Pricing
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="text-sm font-medium hover:text-accent transition-colors"
            >
              Contact
            </button>
          </div>

          {/* CTA Button */}
          <div className="hidden md:block">
            <button
              onClick={() => scrollToSection('contact')}
              className="btn-primary text-sm"
            >
              Contact us
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-background border-b border-border">
            <div className="container py-4 flex flex-col gap-4">
              <button
                onClick={() => scrollToSection('services')}
                className="text-sm font-medium hover:text-accent transition-colors text-left"
              >
                Services
              </button>
              <button
                onClick={() => scrollToSection('work')}
                className="text-sm font-medium hover:text-accent transition-colors text-left"
              >
                Work
              </button>
              <button
                onClick={() => scrollToSection('pricing')}
                className="text-sm font-medium hover:text-accent transition-colors text-left"
              >
                Pricing
              </button>
              <button
                onClick={() => scrollToSection('contact')}
                className="text-sm font-medium hover:text-accent transition-colors text-left"
              >
                Contact
              </button>
              <button
                onClick={() => scrollToSection('contact')}
                className="btn-primary text-sm w-full"
              >
                Contact us
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container max-w-4xl">
          <div className="text-center">
            <div className="inline-block mb-6 px-4 py-2 bg-accent/10 rounded-full border border-accent/20">
              <span className="text-sm font-medium text-accent">AI Automation Agency</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              We build AI agents that work for your business 24/7
            </h1>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              WhatsApp chatbots, lead automation, and custom AI workflows — built for startups and growing businesses worldwide.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <button
                onClick={() => scrollToSection('contact')}
                className="btn-primary"
              >
                Get a free demo
              </button>
              <button
                onClick={() => scrollToSection('work')}
                className="btn-ghost"
              >
                See our work <ArrowRight size={18} className="inline ml-2" />
              </button>
            </div>

            {/* Stats Row */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8 border-t border-border">
              <div>
                <div className="text-3xl font-bold text-accent mb-2">3×</div>
                <p className="text-sm text-muted-foreground">Faster response time</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-accent mb-2">80%</div>
                <p className="text-sm text-muted-foreground">Less manual work</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-accent mb-2">24/7</div>
                <p className="text-sm text-muted-foreground">Always-on automation</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider" />

      {/* What We Do Section */}
      <section id="services" className="py-20 px-4">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">What We Do</h2>
            <p className="text-lg text-muted-foreground">
              Comprehensive AI automation solutions tailored for your business
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* AI Customer Support */}
            <div className="card-base">
              <div className="mb-4 p-3 bg-accent/10 rounded-lg w-fit">
                <MessageSquare className="text-accent" size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3">AI Customer Support</h3>
              <p className="text-muted-foreground">
                Intelligent chatbots that handle customer inquiries 24/7, reducing response time and improving satisfaction.
              </p>
            </div>

            {/* WhatsApp Chatbots */}
            <div className="card-base">
              <div className="mb-4 p-3 bg-accent/10 rounded-lg w-fit">
                <MessageSquare className="text-accent" size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3">WhatsApp Chatbots</h3>
              <p className="text-muted-foreground">
                Automated WhatsApp bots for lead qualification, appointment booking, and customer engagement.
              </p>
            </div>

            {/* N8N Workflows */}
            <div className="card-base">
              <div className="mb-4 p-3 bg-accent/10 rounded-lg w-fit">
                <Zap className="text-accent" size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3">N8N Workflows</h3>
              <p className="text-muted-foreground">
                Custom automation workflows connecting your tools and systems for seamless data flow.
              </p>
            </div>

            {/* Data Analysis */}
            <div className="card-base">
              <div className="mb-4 p-3 bg-accent/10 rounded-lg w-fit">
                <BarChart3 className="text-accent" size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3">Data Analysis</h3>
              <p className="text-muted-foreground">
                Transform raw data into actionable insights with AI-powered analytics and reporting.
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider" />

      {/* How It Works Section */}
      <section className="py-20 px-4">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-lg text-muted-foreground">
              Our proven process from discovery to deployment
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="relative">
              <div className="card-base">
                <div className="text-4xl font-bold text-accent mb-4">01</div>
                <h3 className="text-xl font-bold mb-3">Discovery Call</h3>
                <p className="text-muted-foreground">
                  We understand your business needs, challenges, and goals to design the perfect solution.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative">
              <div className="card-base">
                <div className="text-4xl font-bold text-accent mb-4">02</div>
                <h3 className="text-xl font-bold mb-3">We Build Your Solution</h3>
                <p className="text-muted-foreground">
                  Our team develops and configures your AI automation, ensuring it fits perfectly with your workflow.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative">
              <div className="card-base">
                <div className="text-4xl font-bold text-accent mb-4">03</div>
                <h3 className="text-xl font-bold mb-3">Deploy & Optimise</h3>
                <p className="text-muted-foreground">
                  We launch your solution and continuously optimize performance based on real-world data.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider" />

      {/* Our Work Section */}
      <section id="work" className="py-20 px-4">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Our Work</h2>
            <p className="text-lg text-muted-foreground">
              Real results for businesses worldwide
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Project 1 */}
            <div className="card-base">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-xl font-bold">Real Estate Lead Bot</h3>
                <span className="inline-block px-3 py-1 bg-accent/10 text-accent text-sm font-medium rounded-full">
                  ↑ 3× more qualified leads
                </span>
              </div>
              <p className="text-muted-foreground">
                Automated WhatsApp bot for a real estate agency that qualifies leads and books viewings automatically.
              </p>
            </div>

            {/* Project 2 */}
            <div className="card-base">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-xl font-bold">E-commerce AI Support</h3>
                <span className="inline-block px-3 py-1 bg-accent/10 text-accent text-sm font-medium rounded-full">
                  ↑ 95% satisfaction
                </span>
              </div>
              <p className="text-muted-foreground">
                AI customer support chatbot handling product inquiries, returns, and order tracking 24/7.
              </p>
            </div>

            {/* Project 3 */}
            <div className="card-base">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-xl font-bold">N8N Lead Pipeline</h3>
                <span className="inline-block px-3 py-1 bg-accent/10 text-accent text-sm font-medium rounded-full">
                  ↑ 60% faster processing
                </span>
              </div>
              <p className="text-muted-foreground">
                Automated workflow connecting CRM, email, and payment systems for seamless lead management.
              </p>
            </div>

            {/* Project 4 */}
            <div className="card-base">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-xl font-bold">Automated Reporting</h3>
                <span className="inline-block px-3 py-1 bg-accent/10 text-accent text-sm font-medium rounded-full">
                  ↑ 40 hours saved/month
                </span>
              </div>
              <p className="text-muted-foreground">
                Daily automated reports pulling data from multiple sources and delivering insights to stakeholders.
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider" />

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-4">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Pricing</h2>
            <p className="text-lg text-muted-foreground">
              Flexible solutions for every business size
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {/* Chatbot / WhatsApp */}
            <div className="card-base">
              <h3 className="text-2xl font-bold mb-2">Chatbot</h3>
              <p className="text-muted-foreground mb-6">WhatsApp & AI Support</p>
              <div className="mb-6">
                <span className="text-4xl font-bold">$169</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                  <span className="text-sm">WhatsApp chatbot setup</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                  <span className="text-sm">AI customer support</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                  <span className="text-sm">Lead qualification</span>
                </li>
              </ul>
              <button className="btn-ghost w-full">Get Started</button>
            </div>

            {/* Email Workflow - Featured */}
            <div className="card-base border-2 border-accent relative md:scale-105 md:z-10">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 px-4 py-1 bg-accent text-background text-sm font-bold rounded-full">
                Most Popular
              </div>
              <h3 className="text-2xl font-bold mb-2">Email Workflow</h3>
              <p className="text-muted-foreground mb-6">Automated email campaigns</p>
              <div className="mb-6">
                <span className="text-4xl font-bold">$199</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                  <span className="text-sm">Email automation setup</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                  <span className="text-sm">N8N workflow integration</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                  <span className="text-sm">Lead nurturing sequences</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                  <span className="text-sm">Priority support</span>
                </li>
              </ul>
              <button className="btn-primary w-full">Get Started</button>
            </div>

            {/* Data Analysis Agent */}
            <div className="card-base">
              <h3 className="text-2xl font-bold mb-2">Data Analysis</h3>
              <p className="text-muted-foreground mb-6">AI-powered insights</p>
              <div className="mb-6">
                <span className="text-4xl font-bold">$349</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                  <span className="text-sm">Data analysis agent</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                  <span className="text-sm">Automated reporting</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                  <span className="text-sm">Custom dashboards</span>
                </li>
                <li className="flex items-center gap-3">
                  <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                  <span className="text-sm">Dedicated support</span>
                </li>
              </ul>
              <button
                onClick={() => scrollToSection('contact')}
                className="btn-ghost w-full"
              >
                Get Started
              </button>
            </div>
          </div>

          {/* Custom Solutions */}
          <div className="text-center mt-12 p-8 bg-secondary/30 rounded-lg border border-border">
            <h3 className="text-2xl font-bold mb-2">Any other workflow or agent?</h3>
            <p className="text-muted-foreground mb-6">Let's discuss your custom needs in the contact section below</p>
            <button
              onClick={() => scrollToSection('contact')}
              className="btn-primary"
            >
              Contact us
            </button>
          </div>
        </div>
      </section>

      <div className="section-divider" />

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Left Column */}
            <div>
              <h2 className="text-4xl font-bold mb-6">Let's Talk</h2>
              <p className="text-lg text-muted-foreground mb-8">
                Ready to transform your business with AI automation? Get in touch with our team for a free consultation.
              </p>

              <div className="space-y-6">
                {/* WhatsApp */}
                <a
                  href="https://wa.me/212780852358"
                  className="flex items-center gap-4 p-4 rounded-lg hover:bg-muted transition-colors"
                >
                  <div className="p-3 bg-accent/10 rounded-lg">
                    <MessageSquare className="text-accent" size={24} />
                  </div>
                  <div>
                    <p className="font-medium">WhatsApp</p>
                    <p className="text-muted-foreground">0780852358</p>
                  </div>
                </a>

                {/* Email */}
                <a
                  href="mailto:aadammm877@gmail.com"
                  className="flex items-center gap-4 p-4 rounded-lg hover:bg-muted transition-colors"
                >
                  <div className="p-3 bg-accent/10 rounded-lg">
                    <Mail className="text-accent" size={24} />
                  </div>
                  <div>
                    <p className="font-medium">Email</p>
                    <p className="text-muted-foreground">aadammm877@gmail.com</p>
                  </div>
                </a>
              </div>
            </div>

            {/* Right Column - Contact Form */}
            <ContactForm />
          </div>
        </div>
      </section>

      <div className="section-divider" />

      {/* Footer */}
      <footer className="py-12 px-4 bg-muted/30">
        <div className="container flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center gap-1 font-bold text-lg mb-4 md:mb-0">
            <span className="text-foreground">Flow</span>
            <span className="text-accent">Mind</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © 2025 FlowMind. AI Automation Agency
          </p>
        </div>
      </footer>
    </div>
  );
}
